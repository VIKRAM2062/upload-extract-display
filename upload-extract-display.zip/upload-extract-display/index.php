<?php

error_reporting(0); 

// Check if the upload form is submitted
if(isset($_POST["extract_zip_file"])) {

    $file_output = '';

    //Check any file with the name of zip_file whether it is selected or not
    //by using the conditions to check if the variable name of zip_file is not empty and has a value  
    if($_FILES['zip_file']['name'] != '') {

        //If the variable name of zip_file is has a value, then assign the value to the variable called zip_file_name
        $zip_file_name = $_FILES['zip_file']['name'];

        //Store the uploaded file into an array with the file name and its respective extension. 
        //The explode function is used to store the extension to the respective file
        $file_array = explode(".", $zip_file_name);

        //To store only the uploaded file name
        $file_name = $file_array[0];

        //To store the extension of the uploaded file
        $file_extension = $file_array[1];

        //Check if the uploaded file's extension is a zip file or not
        if($file_extension == 'zip') {

            //If the uploaded file's extension is a zip file, then store the uploaded zip file to the destination path below
            $file_path = 'pictures/';

            //The variable below would store the location of the zip file
            //which contains the file's path as well as the file's name
            $file_location = $file_path . $zip_file_name;

            //Check if uploaded zip file is moved to the file location
            if(move_uploaded_file($_FILES['zip_file']['tmp_name'], $file_location)) {

                //Create ZipArchive object from ZipArchive class and store it to the variable called zip
                $zip = new ZipArchive;

                //Check if zip file is opened 
                if($zip->open($file_location)) {

                    //Extracts the complete archive to the destination path
                    $zip->extractTo($file_path);
                    //Close the ZipArchive class
                    $zip->close();
                }

                //Get all files from extracted folder to upload folder
                //All file names from the extracted folder is stored in the variable below using scan directory (scandir) function
                //scandir function returns an array of files and directories of the specified directory
                $files = scandir($file_path . $file_name);

                //Check if the files are images or not
                //foreach can easily access all files one by one
                foreach($files as $file) {

                    //Store extension of file from extracted folder by using end function 
                    //In the end function, an explode function with a string delimiter and the file is specified 
                    $file_ext = end(explode(".", $file));

                    //Array of allowed file extensions
                    //Since we're extracting pictures from the zip files, jpg and png are the allowed file extensions
                    $allowed_file_ext = array('jpg', 'png');

                    //Check if the file uploaded contains the appropriate file extension or not
                    if(in_array($file_ext, $allowed_file_ext)) {
                        
                        //Variable for image name
                        $image_name = md5(rand()).'.' . $file_ext;

                        //To display the image/images
                        $file_output .= '<img src="pictures/'.$image_name.'" width="350" height="350">';
                        
                        //Copy image file from extracted folder to upload folder
                        copy($file_path.$file_name.'/'.$file, $file_path . $image_name);
                        
                        //Delete the image file from the extracted folder
                        unlink($file_path.$file_name.'/'.$file);


                    } 

                }

                //Delete the zip file from the uploaded folder
                unlink($file_location);
                //Remove the extracted folder. rmdir function basically removes an empty directory like an empty folder
                rmdir($file_path . $file_name);

            }
        }

    }



}

?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Engineering Internship Assessment</title>
  <meta name="description" content="The HTML5 Herald" />
  <meta name="author" content="Digi-X Internship Committee" />

  <link rel="stylesheet" href="style.css?v=1.0" />
  <link rel="stylesheet" href="custom.css?v=1.0" />

</head>

<body>
<!-- 
    <div class="top-wrapper">
        <img src="https://assets.website-files.com/5cd4f29af95bc7d8af794e0e/5cfe060171000aa66754447a_n-digi-x-logo-white-yellow-standard.svg" alt="digi-x logo" height="70" />
        <h1>Engineering Internship Assessment</h1>
    </div>

    <div class="instruction-wrapper">
        <h2>What you need to do?</h2>
        <h3 style="margin-top:31px;">Using this HTML template, create a page that can:</h3>
        <ol>
            <li><b class="yellow">Upload</b> a zip file - containing 5 images (Cats, or Dogs, or even Pokemons)</li>
            <li>after uploading, <b class="yellow">Extract</b> the zip to get the images </li>
            <li><b class="yellow">Display</b> the images on this page</li>
        </ol>

        <h2 style="margin-top:51px;">The rules?</h2>
        <ol>
            <li>May use <b class="yellow">any programming language/script</b>. The simplest the better *wink*</li>
            <li><b class="yellow">Best if this project could be hosted</b></li>
            <li><b class="yellow">If you are not hosting</b>, please provide a video as proof (GDrive video link is ok)</li>
            <li><b class="yellow">Submit your code</b> by pushing to your own github account, and share the link with us</li>
        </ol>
    </div> -->

    <!-- DO NO REMOVE CODE STARTING HERE -->
    <div class="display-wrapper">
        <h2 style="margin-top:51px;">My images</h2>
        <div class="append-images-here">
        
        <p

        <?php
            if(isset($_POST["extract_zip_file"]) && isset($file_output)) {

        ?>    
        hidden="true"<?}?> >No image found. Your extracted images should be here.</p>

                    
            
            <!-- THE IMAGES SHOULD BE DISPLAYED INSIDE HERE -->
                        
            <form method="POST" enctype="multipart/form-data">

                <label>Upload your ZIP file here</label>
                <!-- Input to upload file -->
                <input type="file" name="zip_file"/> 
                <br>
                <input type="submit" name="extract_zip_file" class="btn btn-info" value="Upload"/>
            </form>
            <br>
            <?php
                
                //Check if file_output variable has a value or not
                //If it does, then display the images
                if(isset($file_output)) {

                    echo $file_output;

                } 
            ?>

            
            
        </div>
    </div>
    <!-- DO NO REMOVE CODE UNTIL HERE -->

</body>
</html>